﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace ZavychManagement
{

    class Hotel
    {
        public int Room { get; set; }
        public int Floor { get; set; }
        public string Type { get; set; }
        public int Price { get; set; }
        public string ClientsList { get; set; }
        public string WorkersList { get; set; }


        public Hotel() { }
        public Hotel(int r, int f, string t, int p, string c, string w)
        { Room = r; Floor = f; Type = t; Price = p; ClientsList = c; WorkersList = w; }
    }

    class Client
    {
        public int Key { get; set; }
        public string Name { get; set; }
        public string PassportNumber { get; set; }
        public string From { get; set; }
        public int Room { get; set; }
        public string Place { get; set; }
        public string Arrived { get; set; }
        public int Payment { get; set; }


        public Client() { }
        public Client(int k, string n, string p, string f, int r, string pl, string a, int pay)
        { Key = k; Name = n; PassportNumber = p; From = f; Room = r; Place = pl; Arrived = a; Payment = pay; }
    }

    class Employee
    {
        public int Key { get; set; }
        public string Name { get; set; }
        public string FloorsList { get; set; }
        public string DaysList { get; set; }

        public Employee(int k, string n, string fl, string dl)
        { Key = k; Name = n; FloorsList = fl; DaysList = dl; }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;

            string basePath = "../../../Data/";
            List<Hotel> Hotels = new List<Hotel>();
            List<Client> Clients = new List<Client>();
            List<Employee> Employees = new List<Employee>();

            string HotelsFilePath = basePath + "Rooms.txt";
            string ClientsFilePath = basePath + "Clients.txt";
            string EmployeesFilePath = basePath + "Employees.txt";

            StreamReader HotelsFileReader = new StreamReader(HotelsFilePath, Encoding.Default);
            string HotelsTextLine;

            while ((HotelsTextLine = HotelsFileReader.ReadLine()) != null)
            {
                string[] strings = HotelsTextLine.Split(';');
                int room = int.Parse(strings[0]);
                int floor = int.Parse(strings[1]);
                string type = strings[2];
                int price = int.Parse(strings[3]);
                string clientsList = strings[4];
                string workersList = strings[5];

                Hotels.Add(new Hotel(room, price, type, floor, clientsList, workersList));
            }

                HotelsFileReader.Close();
            

                StreamReader ClientsFileReader = new StreamReader(ClientsFilePath, Encoding.Default);
                string ClientsTextLine;
            


                while ((ClientsTextLine = ClientsFileReader.ReadLine()) != null)
                {
                    string[] strings = ClientsTextLine.Split(';');

                    int key = int.Parse(strings[0]);
                    string name = strings[1];
                    string passportNumber = strings[2];
                    string from = strings[3];
                    int room = int.Parse(strings[4]);
                    string place = strings[5];
                    string arrived = strings[6];
                    int payment = int.Parse(strings[7]);

                    Clients.Add(new Client(key, name, passportNumber, from, room, place, arrived, payment));
                }
                ClientsFileReader.Close();


                StreamReader EmployeesFileReader = new StreamReader(EmployeesFilePath, Encoding.Default);
                string EmployeesTextLine;


                while ((EmployeesTextLine = EmployeesFileReader.ReadLine()) != null)
                {
                    string[] strings = EmployeesTextLine.Split(';');

                    int key = int.Parse(strings[0]);
                    string name = strings[1];
                    string floorslist = strings[2];
                    string dayslist = strings[3];

                    Employees.Add(new Employee(key, name, floorslist, dayslist));
                }
                EmployeesFileReader.Close();


                Console.WriteLine();

                string menuPoint = "";

                Console.WriteLine("Оберіть дію: ");
                Console.WriteLine("0 - вийти з програми"); // +
                Console.WriteLine("1 - список всіх номерів"); // +
                Console.WriteLine("2 - список всіх клієнтів"); // +
                Console.WriteLine("3 - список всіх працівників"); // +
                Console.WriteLine("4 - вартість місця для заданого поверху та номера"); //
                Console.WriteLine("5 - список клієнтів, що прибули із заданого місця"); // +
                Console.WriteLine("6 - хто із службовців прибрав номер вказаного клієнта у заданий день тижня"); //
                Console.WriteLine("7 - скільки у готелі вільних місць та номерів"); // +
                Console.WriteLine("8 - клієнти, які мешкаюсь в одномісних номерах"); // +
                Console.WriteLine("9 - загальна сума виплачена всіма клієнтами"); // +
                Console.WriteLine("10 - прийняти (додати) нового працівника"); // +
                Console.WriteLine("11 - звільнити (видалити) працівника"); // +




                while (menuPoint != "0")
                {
                    Console.WriteLine("- - - - - - - - - - - - - - - - - - -");
                    menuPoint = Console.ReadLine();

                    if (menuPoint == "1")
                    {
                        foreach (Hotel t in Hotels)
                        {
                            Console.WriteLine($"{t.Room}\t{t.Floor}\t{t.Type}\t{t.Price}\t{t.ClientsList}\t{t.WorkersList}\t");
                        }
                    }
                    if (menuPoint == "2")
                    {
                        foreach (Client s in Clients)
                        {
                            Console.WriteLine($"{s.Key}\t{s.Name}\t{s.PassportNumber}\t{s.From}\t{s.Room}\t{s.Place}\t{s.Arrived}\t{s.Payment}\t");
                        }
                    }
                    if (menuPoint == "3")
                    {
                        foreach (Employee s in Employees)
                        {
                            Console.OutputEncoding = Encoding.UTF8;
                            Console.WriteLine($"{s.Key}\t{s.Name}\t{s.FloorsList}\t{s.DaysList}\t");
                        }
                    }
                    if (menuPoint == "10")
                    {
                        Console.OutputEncoding = Encoding.UTF8;
                        Console.InputEncoding = Encoding.UTF8;
                        string EmployeeKey = (Employees.Max(Employee => Employee.Key) + 1).ToString();
                        Console.WriteLine("Введіть прізвище та ім'я працівника:");
                        string EmployeeName = Console.ReadLine();
                        Console.WriteLine("Введіть робочі поверхи:");
                        string EmployeeFloorsList = Console.ReadLine();
                        Console.WriteLine("Введіть робочі дні тижня:");
                        string EmployeeDaysList = Console.ReadLine();

                        Employees.Add(new Employee(int.Parse(EmployeeKey), EmployeeName, EmployeeFloorsList, EmployeeDaysList));
                        Console.WriteLine($"{EmployeeName} - доданий(а) до списку працівників");
                    }
                    if (menuPoint == "11")
                    {
                        Console.WriteLine("Введіть номер працівника зі списку, котрого потрібно звільнити: ");
                        foreach (Employee t in Employees)
                        {

                            Console.WriteLine($"{t.Key}\t{t.Name}\t{t.FloorsList}\t{t.DaysList}\t");
                        }
                        string selectedKey = Console.ReadLine();
                        int EmployeeKey = int.Parse(selectedKey);


                        Employee EmployeeToRemove = Employees.Where(Employee => Employee.Key == EmployeeKey).FirstOrDefault();

                        if (EmployeeToRemove != null)
                        {
                            Employees.Remove(EmployeeToRemove);
                            Console.WriteLine("Працівника звільнено");
                        }
                        if (EmployeeToRemove == null)
                        {
                            Console.WriteLine("Працівника не знайдено");
                        }
                    }
                    if (menuPoint == "9")
                    {
                        int Summ = 0;
                        foreach (Client s in Clients)
                        {
                            Console.WriteLine($"{s.Key}\t{s.Name}\t{s.PassportNumber}\t{s.From}\t{s.Room}\t{s.Place}\t{s.Arrived}\t{s.Payment}\t");
                            Summ += s.Payment;
                        }
                        Console.WriteLine($"Загальна сумма = {Summ}");
                    }
                    if (menuPoint == "8")
                    {
                        int i = 0;
                        string[] ClientArray = new string[100];

                        foreach (Hotel s in Hotels)
                        {
                            Console.WriteLine($"{s.Room}\t{s.Floor}\t{s.Type}\t{s.Price}\t{s.ClientsList}\t{s.WorkersList}\t");

                            if (s.Type.Contains("1"))
                            {
                                ClientArray[i] = s.ClientsList + ",";
                            }
                            i++;
                        }

                        if (ClientArray.Any())
                        {
                            Console.WriteLine($"Клієнти {string.Join("", ClientArray)} - мешкають в одномісному номері\t");
                        }
                        else
                        {
                            Console.WriteLine("Немає клієнтів які мешкають в одномісних номерах");
                        }

                        i = 0;
                    }
                    if (menuPoint == "7")
                    {
                        int Summ = 0;
                        foreach (Hotel s in Hotels)
                        {
                            Console.WriteLine($"{s.Room}\t{s.Floor}\t{s.Type}\t{s.Price}\t{s.ClientsList}\t{s.WorkersList}\t");
                            if (s.ClientsList.Contains("-"))
                            {
                                Summ++;
                            }
                        }
                        Console.WriteLine($"Кількість вільних номерів = {Summ}");
                    }
                    if (menuPoint == "5")
                    {
                        int i = 0;
                        string[] ClientArray = new string[100];

                        Console.OutputEncoding = Encoding.UTF8;
                        Console.InputEncoding = Encoding.UTF8;

                        string place = Console.ReadLine();


                        foreach (Client s in Clients)
                        {

                            if (s.From == " " + place)
                            {
                                ClientArray[i] = s.Name + ",";
                            }
                            i++;
                        }

                        if (ClientArray.Any())
                        {
                            Console.WriteLine($"Клієнти {string.Join("", ClientArray)} - прибули із заданого місця\t");
                        }
                        else
                        {
                            Console.WriteLine("Немає клієнтів із заданого місця");
                        }

                        i = 0;
                    }
                }
            }
        }
    }